<?php

if(isset($_POST['submit']))
{
	echo $la=$_POST['la'];
	echo $lon=$_POST['lon'];	


}
?>