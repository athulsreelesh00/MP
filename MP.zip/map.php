<!doctype html>
<html>
    <head></head>
    <body>
        <a target="blank" class="text-white" href="http://www.google.com/maps/place/9.531650,76.820450">Location</a>
    </body>
</html>