<?php
$con=mysqli_connect("localhost","root","","miniproject2021");
/*if(!$con)
	echo"not connected";
else
	echo"Connected";*/
?>